insert into new_demo.new_tbl values(1,'Reshma',24),(2,'Anisha',27),(3,'Akshaya',26);
